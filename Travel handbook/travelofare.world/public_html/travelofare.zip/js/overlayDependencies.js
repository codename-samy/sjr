if(window.location.pathname==="/email/sweepstake/wander_the_world_with_Travelofare"){window.location.href='/?utm_source=email&utm_medium=cheapflights_newsletter&campaign=16602';}
var overlay=overlay||{};overlay.legalsContent={};overlay.global_location='https://www.Travelofare.com/';
